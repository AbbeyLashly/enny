jQuery('#datetimepicker').datetimepicker({
	timepicker:true,
	format:'Y-m-d H:i:s'
});