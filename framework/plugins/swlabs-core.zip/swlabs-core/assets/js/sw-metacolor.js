jQuery(document).ready(function($) {
	"use strict";
	$('.swlabscore-meta-color').wpColorPicker();
});