<?php
printf('<div id="accordion-%s" class="accordion-%s %s panel-group accordion accordion-white shw-shortcode ">%s</div>', $layout, $layout, $extra_class, $content );
?>